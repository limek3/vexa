'use client';

import dynamic from 'next/dynamic';

type DesktopScreen =
  | 'dashboard'
  | 'schedule'
  | 'clients'
  | 'chats'
  | 'services'
  | 'availability'
  | 'profile'
  | 'public'
  | 'appearance'
  | 'templates'
  | 'notifications'
  | 'integrations'
  | 'analytics'
  | 'reviews'
  | 'subscription'
  | 'account'
  | 'settings'
  | 'finance'
  | 'marketing'
  | 'payments'
  | 'limits'
  | 'sources'
  | 'help';

const loading = () => (
  <div className="cb-desktop-html" data-theme="light" data-accent="clay" data-density="default" data-radius="default"><div className="boot-exact"><span>к</span><div><strong>КликБук</strong><em>Открываем рабочий кабинет...</em></div></div></div>
);

const apps = {
  dashboard: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopDashboardApp), { ssr: false, loading }),
  schedule: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopScheduleApp), { ssr: false, loading }),
  clients: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopClientsApp), { ssr: false, loading }),
  chats: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopChatsApp), { ssr: false, loading }),
  services: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopServicesApp), { ssr: false, loading }),
  availability: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopAvailabilityApp), { ssr: false, loading }),
  profile: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopProfileApp), { ssr: false, loading }),
  public: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopPublicApp), { ssr: false, loading }),
  appearance: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopAppearanceApp), { ssr: false, loading }),
  templates: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopTemplatesApp), { ssr: false, loading }),
  notifications: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopNotificationsApp), { ssr: false, loading }),
  integrations: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopIntegrationsApp), { ssr: false, loading }),
  analytics: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopAnalyticsApp), { ssr: false, loading }),
  reviews: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopReviewsApp), { ssr: false, loading }),
  subscription: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopSubscriptionApp), { ssr: false, loading }),
  account: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopAccountApp), { ssr: false, loading }),
  settings: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopSettingsApp), { ssr: false, loading }),
  finance: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopFinanceApp), { ssr: false, loading }),
  marketing: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopMarketingApp), { ssr: false, loading }),
  payments: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopPaymentsApp), { ssr: false, loading }),
  limits: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopLimitsApp), { ssr: false, loading }),
  sources: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopSourcesApp), { ssr: false, loading }),
  help: dynamic(() => import('./desktop-workspace').then((mod) => mod.DesktopHelpApp), { ssr: false, loading }),
};

export function DesktopScreenApp({ screen }: { screen: DesktopScreen }) {
  const App = apps[screen] ?? apps.dashboard;
  return <App />;
}
