import { DesktopScreenApp } from '@/app/desktop/_components/desktop-entry';

export default function DesktopAccountPage() {
  return <DesktopScreenApp screen="account" />;
}
