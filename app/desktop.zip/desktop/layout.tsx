import type { ReactNode } from 'react';
import './desktop.css';

export default function DesktopLayout({ children }: { children: ReactNode }) {
  return children;
}
