import { redirect } from 'next/navigation';

export default function DesktopIndexPage() {
  redirect('/desktop/dashboard?demo=1');
}
